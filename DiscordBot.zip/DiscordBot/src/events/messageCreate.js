const { Events } = require("discord.js");

module.exports = {
    name: Events.MessageCreate,
    once: false,
    execute(message) {
        console.log(message.content);
        if(message.content === '/Example'){ // This is command you type in the server (case sensitive)
            message.reply('Made by @fd_q'); // This is the message that you get replied.
        
        }
    },
};
