const { Events, ActivityType } = require("discord.js");

module.exports = {
    name: Events.ClientReady,
    once: true,
    execute(client) {
        console.log('Ready! You Have Been Logged In As Admin :)'); // Message that appears in terminal when script started
   
    client.user.setActivity({
        name: "Change this in bot settings.", // Custom activity name.
        type: ActivityType.Competing, // Activity type (Competing is default)
        
    });   
    },
};
